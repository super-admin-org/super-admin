<?php

namespace SuperAdmin\Admin\Form\Field;

class Month extends Date
{
    protected $format = 'MM';
}
