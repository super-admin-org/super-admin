<?php

namespace SuperAdmin\Admin\Grid\Displayers\Actions;

class ContextMenuActions extends DropdownActions
{
    protected $view = 'admin::grid.actions.contextmenu';
}
