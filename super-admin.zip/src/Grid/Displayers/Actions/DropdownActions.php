<?php

namespace SuperAdmin\Admin\Grid\Displayers\Actions;

class DropdownActions extends Actions
{
    protected $view = 'admin::grid.actions.dropdown';

    public $showLabels = true;
}
