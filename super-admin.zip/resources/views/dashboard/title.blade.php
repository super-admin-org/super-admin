<div class="dashboard-title">
    Resources
</div>
<div class="dashboard-links">
    <a href="https://github.com/super-admin-org/super-admin" target="_blank">Github</a> -
    <a href="http://super-admin.org/docs"  target="_blank">Documentation</a> -
    <a href="http://super-admin.org/demo"  target="_blank">Demo</a>
</div>