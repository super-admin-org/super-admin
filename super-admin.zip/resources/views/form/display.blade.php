@include("admin::form._header")

    <div class="form-value">
        {!! $value !!}&nbsp;
    </div>

@include("admin::form._footer")