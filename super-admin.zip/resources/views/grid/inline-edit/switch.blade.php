<div class="form-check form-switch">
  <input class="form-check-input {{ $class }}" {{ $checked }} data-key="{{ $key }}" type="checkbox">
</div>

@include("admin::grid/inline-edit/switch-script")