<footer class="navbar navbar-light bg-white py-3 px-4 @if (!empty($fixedFooter))shadow fixed-bottom @endif">
    <div class="flex-grow-1">{!!$range!!}</div>
    <div class="pe-2">{!!$per_page!!}</div>
    <div>{!!$links!!}</div>
</footer>
